create definer = playground@`%` view 판매데이터 as
select `so`.`prodno`   AS `prodno`,
       `so`.`custid`   AS `custid`,
       `so`.`ordno`    AS `ordno`,
       `so`.`qty`      AS `qty`,
       `so`.`addr`     AS `addr`,
       `so`.`orddate`  AS `orddate`,
       `sc`.`name`     AS `name`,
       `sc`.`age`      AS `age`,
       `sc`.`grade`    AS `grade`,
       `sc`.`job`      AS `job`,
       `sc`.`points`   AS `points`,
       `sp`.`prdname`  AS `prdname`,
       `sp`.`stock`    AS `stock`,
       `sp`.`price`    AS `price`,
       `sp`.`prdmaker` AS `prdmaker`
from ((`playground`.`sales_orders` `so` join `playground`.`sales_customers` `sc` on (`so`.`custid` = `sc`.`custid`))
         join `playground`.`sales_products` `sp` on (`so`.`prodno` = `sp`.`prodno`));

