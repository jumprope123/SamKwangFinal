create definer = playground@`%` view 우수고객 as
select `playground`.`sales_customers`.`custid` AS `custid`,
       `playground`.`sales_customers`.`name`   AS `name`,
       `playground`.`sales_customers`.`age`    AS `age`
from `playground`.`sales_customers`
where `playground`.`sales_customers`.`grade` = 'vip';

