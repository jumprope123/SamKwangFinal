create definer = playground@`%` view empdeptloc as
select `e`.`employee_id`     AS `employee_id`,
       `e`.`last_name`       AS `last_name`,
       `e`.`first_name`      AS `first_name`,
       `e`.`email`           AS `email`,
       `e`.`department_id`   AS `department_id`,
       `d`.`department_name` AS `department_name`,
       `d`.`location_id`     AS `location_id`,
       `l`.`city`            AS `city`,
       `l`.`country_id`      AS `country_id`,
       `e`.`manager_id`      AS `manager_id`
from ((`playground`.`employees` `e` join `playground`.`departments2` `d` on (`e`.`department_id` = `d`.`department_id`))
         join `playground`.`locations` `l` on (`d`.`location_id` = `l`.`location_id`));

